from PyQt5.QtWidgets import (
    QDialog, QHBoxLayout, QVBoxLayout, QWidget, QSplitter, 
    QTableWidget, QTableWidgetItem, QPushButton, QColorDialog, 
    QDoubleSpinBox, QComboBox, QHeaderView, QLabel
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure


class MiniOriginDialog(QDialog):
    """
    Okno w stylu mini-Origin:
    - Wyświetla krzywe (np. LinearVoltammetry)
    - Pozwala na żywo zmieniać barwę, grubość i styl linii każdej krzywej.
    """
    def __init__(self, experiments, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mini Origin - Curve Styler & Plotter")
        self.resize(1200, 750)
        self.experiments = experiments
        
        # Słownik przechowujący obiekty linii z Matplotliba: {row_index: matplotlib_line2d}
        self.lines_map = {}

        self.setup_ui()
        self.plot_initial_data()

    def setup_ui(self):
        main_layout = QHBoxLayout(self)

        # --- LEWY PANEL KONTROLNY (Tabela z seriami) ---
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.addWidget(QLabel("<b>Warstwy i stylizacja krzywych:</b>"))

        # Tabela: Nazwa | Kolor | Grubość | Styl linii
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Krzywa", "Kolor", "Grubość", "Styl"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        
        left_layout.addWidget(self.table)

        # --- PRAWY PANEL (Wykres Matplotlib) ---
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.figure = Figure(figsize=(8, 6), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.toolbar = NavigationToolbar(self.canvas, self)
        self.ax = self.figure.add_subplot(111)
        self.ax.grid(True, linestyle="--", alpha=0.6)
        self.ax.set_xlabel("Potential [V]")
        self.ax.set_ylabel("Current [A]")

        right_layout.addWidget(self.canvas)
        right_layout.addWidget(self.toolbar)

        # Splitter łączący lewy i prawy panel
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setSizes([450, 750])
        splitter.setCollapsible(0, False)

        main_layout.addWidget(splitter)

    def plot_initial_data(self):
        """Wczytuje eksperymenty, nanosi je na wykres i buduje wiersze tabeli."""
        self.table.setRowCount(0)
        self.ax.clear()
        self.ax.grid(True, linestyle="--", alpha=0.6)

        default_colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]

        row = 0
        for exp in self.experiments:
            # Pobieranie danych z eksperymentu
            # Dopasuj do swojej implementacji (np. exp.data_list[0] lub exp.get_plot_data())
            df = getattr(exp, 'df', None)
            if df is None and hasattr(exp, 'data_list') and exp.data_list:
                df = exp.data_list[0]

            if df is None:
                continue

            # Dobór kolumn (standardowo Potential vs Current)
            x_col = [c for c in df.columns if 'V' in c or 'Potential' in c]
            y_col = [c for c in df.columns if 'I' in c or 'Current' in c]
            
            x_name = x_col[0] if x_col else df.columns[0]
            y_name = y_col[0] if y_col else df.columns[1]

            color = default_colors[row % len(default_colors)]
            label = getattr(exp, 'file_name', f"Curve {row+1}")

            # Rysowanie linii na wykresie
            line, = self.ax.plot(df[x_name], df[y_name], label=label, color=color, linewidth=1.5, linestyle="-")
            self.lines_map[row] = line

            # Wstawienie wiersza do tabeli kontrolek
            self.table.insertRow(row)

            # 1. Nazwa krzywej
            name_item = QTableWidgetItem(label)
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(row, 0, name_item)

            # 2. Przycisk wyboru koloru
            btn_color = QPushButton()
            btn_color.setStyleSheet(f"background-color: {color}; border: 1px solid #555; border-radius: 3px; min-width: 35px;")
            btn_color.clicked.connect(lambda checked, r=row, b=btn_color: self.choose_color(r, b))
            self.table.setCellWidget(row, 1, btn_color)

            # 3. Grubość linii (SpinBox)
            spin_width = QDoubleSpinBox()
            spin_width.setRange(0.5, 10.0)
            spin_width.setSingleStep(0.5)
            spin_width.setValue(1.5)
            spin_width.valueChanged.connect(lambda val, r=row: self.change_line_width(r, val))
            self.table.setCellWidget(row, 2, spin_width)

            # 4. Styl linii (ComboBox)
            combo_style = QComboBox()
            combo_style.addItems(["Solid (-)", "Dashed (--)", "Dotted (:)", "Dash-Dot (-.)"])
            combo_style.currentIndexChanged.connect(lambda idx, r=row: self.change_line_style(r, idx))
            self.table.setCellWidget(row, 3, combo_style)

            row += 1

        self.ax.legend()
        self.canvas.draw_idle()

    def choose_color(self, row, button):
        """Otwiera próbnik barw i aktualizuje wykres."""
        line = self.lines_map.get(row)
        if not line:
            return

        current_color = QColor(line.get_color())
        new_color = QColorDialog.getColor(current_color, self, "Wybierz kolor krzywej")
        
        if new_color.isValid():
            hex_color = new_color.name()
            button.setStyleSheet(f"background-color: {hex_color}; border: 1px solid #555; border-radius: 3px;")
            line.set_color(hex_color)
            self.ax.legend()
            self.canvas.draw_idle()

    def change_line_width(self, row, width):
        line = self.lines_map.get(row)
        if line:
            line.set_linewidth(width)
            self.canvas.draw_idle()

    def change_line_style(self, row, style_index):
        styles = ["-", "--", ":", "-."]
        line = self.lines_map.get(row)
        if line:
            line.set_linestyle(styles[style_index])
            self.ax.legend()
            self.canvas.draw_idle()